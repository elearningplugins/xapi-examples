/* Tin Can configuration */

//
// ActivityID that is sent for the statement's object
//
TC_COURSE_ID = "http://ZI-MCAm0hUuP-Y8mV4GVnjsXAtFDztu6_rise"

//
// CourseName for the activity
//
TC_COURSE_NAME = {
  "en-US": "Quiz with a passing score of 70%"
};

//
// CourseDesc for the activity
//
TC_COURSE_DESC = {
  "en-US": "&lt;p&gt;All quiz question types in Rise&lt;/p&gt;"
};
