TabletResponsive={"1009":{
"pageLayer":{"w":1009,"h":662,"bgColor":"#ffffff"}
,
"text2639":{"x":900,"y":0,"w":109,"h":19,"txtscale":100,"bOffBottom":0}
,
"button1684":{"B64":{"disabledState":"","downState":"","normalState":"","overState":""},"bOffBottom":0,"h":42,"p":"M 11.000000 1.000000 L 111.000000 1.000000 L 113.000000 1.187500 L 114.937500 1.812500 L 118.062500 3.937500 L 120.250000 7.125000 L 120.812500 9.000000 L 121.000000 11.000000 L 121.000000 31.000000 L 120.812500 33.000000 L 120.250000 34.937500 L 118.062500 38.062500 L 114.937500 40.250000 L 113.000000 40.812500 L 111.000000 41.000000 L 11.000000 41.000000 L 7.187500 40.250000 L 3.937500 38.125000 L 1.750000 34.875000 L 1.187500 33.000000 L 1.000000 31.000000 L 1.000000 11.000000 L 1.187500 9.000000 L 1.812500 7.125000 L 3.937500 3.937500 L 7.125000 1.812500 L 9.000000 1.187500 L 11.000000 1.000000 z","stylemods":[{"decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:120.000000px; height:40.000000px;}","sel":"div.button1684Text"},{"decl":" { width:112.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button1684Text"},{"decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:120.000000px; height:40.000000px;}","sel":"div.button1684overStateText"},{"decl":" { width:112.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button1684overStateText"},{"decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:120.000000px; height:40.000000px;}","sel":"div.button1684downStateText"},{"decl":" { width:112.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button1684downStateText"},{"decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:120.000000px; height:40.000000px;}","sel":"div.button1684disabledStateText"},{"decl":" { width:112.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button1684disabledStateText"}],"w":122,"x":140,"y":312}
,
"shape6027":{"x":-1,"y":47,"w":1011.000000,"h":90.000000,"stylemods":[{"sel":"div.shape6027Text","decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:1009.000000px; height:88.000000px;}"},{"sel":"span.shape6027Text","decl":" { width:1005.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAA/MAAABaCAYAAAD0BwYYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAF3SURBVHhe7cExAQAAAMKg9U/tZwogAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOBqjl0AAUMqMU8AAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 1.000000 1.000000 L 1010.000000 1.000000 L 1010.000000 89.000000 L 1.000000 89.000000 L 1.000000 1.000000 z"}
,
"text1574":{"x":140,"y":74,"w":729,"h":37,"txtscale":100,"bOffBottom":0}
,
"text1575":{"x":140,"y":175,"w":20,"h":28,"txtscale":100,"bOffBottom":0}
,
"text1576":{"x":644,"y":175,"w":20,"h":28,"txtscale":100,"bOffBottom":0}
,
"text1577":{"x":140,"y":222,"w":20,"h":28,"txtscale":100,"bOffBottom":0}
,
"text1578":{"x":644,"y":222,"w":21,"h":28,"txtscale":100,"bOffBottom":0}
,
"text1579":{"x":140,"y":269,"w":21,"h":28,"txtscale":100,"bOffBottom":0}
,
"text1580":{"x":644,"y":269,"w":20,"h":28,"txtscale":100,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}

Init_qu1572(false, true);
}
,
"RCDResultResize":function(){}
,"preload":[]
},
"785":{
"pageLayer":{"w":785,"h":1000,"bgColor":"#ffffff"}
,
"text2639":{"x":700,"y":0,"w":85,"h":18,"txtscale":100,"bOffBottom":0}
,
"button1684":{"B64":{"disabledState":"","downState":"","normalState":"","overState":""},"bOffBottom":0,"h":33,"p":"M 8.000000 1.000000 L 87.000000 1.000000 L 89.750000 1.562500 L 91.937500 3.062500 L 93.437500 5.312500 L 94.000000 8.000000 L 94.000000 25.000000 L 93.437500 27.750000 L 91.937500 29.937500 L 89.750000 31.437500 L 87.000000 32.000000 L 8.000000 32.000000 L 5.375000 31.500000 L 3.062500 30.000000 L 1.562500 27.687500 L 1.000000 25.000000 L 1.000000 8.000000 L 1.562500 5.312500 L 3.062500 3.062500 L 5.312500 1.562500 L 8.000000 1.000000 z","stylemods":[{"decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:93.000000px; height:31.000000px;}","sel":"div.button1684Text"},{"decl":" { width:87.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button1684Text"},{"decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:93.000000px; height:31.000000px;}","sel":"div.button1684overStateText"},{"decl":" { width:87.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button1684overStateText"},{"decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:93.000000px; height:31.000000px;}","sel":"div.button1684downStateText"},{"decl":" { width:87.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button1684downStateText"},{"decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:93.000000px; height:31.000000px;}","sel":"div.button1684disabledStateText"},{"decl":" { width:87.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button1684disabledStateText"}],"w":95,"x":109,"y":312}
,
"shape6027":{"x":-1,"y":47,"w":787.000000,"h":70.000000,"stylemods":[{"sel":"div.shape6027Text","decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:785.000000px; height:68.000000px;}"},{"sel":"span.shape6027Text","decl":" { width:781.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAxMAAABGCAYAAAC38cmJAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADtSURBVHhe7cExAQAAAMKg9U9tCj8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOKsBXTsAAancZPgAAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 1.000000 1.000000 L 786.000000 1.000000 L 786.000000 69.000000 L 1.000000 69.000000 L 1.000000 1.000000 z"}
,
"text1574":{"x":108,"y":155,"w":568,"h":56,"txtscale":100,"bOffBottom":0}
,
"text1575":{"x":108,"y":200,"w":21,"h":28,"txtscale":100,"bOffBottom":0}
,
"text1576":{"x":500,"y":200,"w":21,"h":28,"txtscale":100,"bOffBottom":0}
,
"text1577":{"x":108,"y":227,"w":21,"h":28,"txtscale":100,"bOffBottom":0}
,
"text1578":{"x":500,"y":227,"w":22,"h":28,"txtscale":100,"bOffBottom":0}
,
"text1579":{"x":108,"y":254,"w":22,"h":28,"txtscale":100,"bOffBottom":0}
,
"text1580":{"x":500,"y":254,"w":21,"h":28,"txtscale":100,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}

Init_qu1572(false, true);
}
,
"RCDResultResize":function(){}
,"preload":[]
}}
