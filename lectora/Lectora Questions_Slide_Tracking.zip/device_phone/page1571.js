PhoneResponsive={"785":{
"pageLayer":{"w":785,"h":450,"bgColor":"#ffffff"}
,
"text2639":{"x":700,"y":0,"w":85,"h":18,"txtscale":100,"bOffBottom":0}
,
"button1684":{"B64":{"disabledState":"","downState":"","normalState":"","overState":""},"bOffBottom":0,"h":33,"p":"M 8.000000 1.000000 L 87.000000 1.000000 L 89.750000 1.562500 L 91.937500 3.062500 L 93.437500 5.312500 L 94.000000 8.000000 L 94.000000 25.000000 L 93.437500 27.750000 L 91.937500 29.937500 L 89.750000 31.437500 L 87.000000 32.000000 L 8.000000 32.000000 L 5.375000 31.500000 L 3.062500 30.000000 L 1.562500 27.687500 L 1.000000 25.000000 L 1.000000 8.000000 L 1.562500 5.312500 L 3.062500 3.062500 L 5.312500 1.562500 L 8.000000 1.000000 z","stylemods":[{"decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:93.000000px; height:31.000000px;}","sel":"div.button1684Text"},{"decl":" { width:87.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button1684Text"},{"decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:93.000000px; height:31.000000px;}","sel":"div.button1684overStateText"},{"decl":" { width:87.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button1684overStateText"},{"decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:93.000000px; height:31.000000px;}","sel":"div.button1684downStateText"},{"decl":" { width:87.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button1684downStateText"},{"decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:93.000000px; height:31.000000px;}","sel":"div.button1684disabledStateText"},{"decl":" { width:87.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button1684disabledStateText"}],"w":95,"x":109,"y":243}
,
"shape6027":{"x":-1,"y":36,"w":787.000000,"h":70.000000,"stylemods":[{"sel":"div.shape6027Text","decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:785.000000px; height:68.000000px;}"},{"sel":"span.shape6027Text","decl":" { width:781.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAxMAAABGCAYAAAC38cmJAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADtSURBVHhe7cExAQAAAMKg9U9tCj8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOKsBXTsAAancZPgAAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 1.000000 1.000000 L 786.000000 1.000000 L 786.000000 69.000000 L 1.000000 69.000000 L 1.000000 1.000000 z"}
,
"text1574":{"x":108,"y":155,"w":568,"h":56,"txtscale":100,"bOffBottom":0}
,
"text1575":{"x":108,"y":200,"w":21,"h":28,"txtscale":100,"bOffBottom":0}
,
"text1576":{"x":500,"y":200,"w":21,"h":28,"txtscale":100,"bOffBottom":0}
,
"text1577":{"x":108,"y":227,"w":21,"h":28,"txtscale":100,"bOffBottom":0}
,
"text1578":{"x":500,"y":227,"w":22,"h":28,"txtscale":100,"bOffBottom":0}
,
"text1579":{"x":108,"y":254,"w":22,"h":28,"txtscale":100,"bOffBottom":0}
,
"text1580":{"x":500,"y":254,"w":21,"h":28,"txtscale":100,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}

Init_qu1572(false, true);
}
,
"RCDResultResize":function(){}
,"preload":[]
},
"480":{
"pageLayer":{"w":480,"h":763,"bgColor":"#ffffff"}
,
"text2639":{"x":428,"y":0,"w":52,"h":18,"txtscale":100,"bOffBottom":0}
,
"button1684":{"B64":{"disabledState":"","downState":"","normalState":"","overState":""},"bOffBottom":0,"h":21,"p":"M 5.000000 1.000000 L 54.000000 1.000000 L 55.562500 1.312500 L 56.875000 2.187500 L 57.687500 3.437500 L 58.000000 5.000000 L 58.000000 16.000000 L 57.687500 17.562500 L 56.875000 18.875000 L 55.562500 19.687500 L 54.000000 20.000000 L 5.000000 20.000000 L 3.500000 19.750000 L 2.187500 18.875000 L 1.312500 17.562500 L 1.000000 16.000000 L 1.000000 5.000000 L 1.312500 3.437500 L 2.187500 2.187500 L 3.437500 1.312500 L 5.000000 1.000000 z","stylemods":[{"decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:57.000000px; height:19.000000px;}","sel":"div.button1684Text"},{"decl":" { width:51.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button1684Text"},{"decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:57.000000px; height:19.000000px;}","sel":"div.button1684overStateText"},{"decl":" { width:51.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button1684overStateText"},{"decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:57.000000px; height:19.000000px;}","sel":"div.button1684downStateText"},{"decl":" { width:51.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button1684downStateText"},{"decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:57.000000px; height:19.000000px;}","sel":"div.button1684disabledStateText"},{"decl":" { width:51.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button1684disabledStateText"}],"w":59,"x":66,"y":312}
,
"shape6027":{"x":-1,"y":47,"w":482.000000,"h":44.000000,"stylemods":[{"sel":"div.shape6027Text","decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:480.000000px; height:42.000000px;}"},{"sel":"span.shape6027Text","decl":" { width:476.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAeIAAAAsCAYAAAC5fLvTAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABoSURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAt2pLmwAB3OvSpQAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 1.000000 1.000000 L 481.000000 1.000000 L 481.000000 43.000000 L 1.000000 43.000000 L 1.000000 1.000000 z"}
,
"text1574":{"x":66,"y":95,"w":347,"h":74,"txtscale":100,"bOffBottom":0}
,
"text1575":{"x":66,"y":177,"w":21,"h":28,"txtscale":100,"bOffBottom":0}
,
"text1576":{"x":306,"y":177,"w":21,"h":28,"txtscale":100,"bOffBottom":0}
,
"text1577":{"x":66,"y":204,"w":21,"h":28,"txtscale":100,"bOffBottom":0}
,
"text1578":{"x":306,"y":204,"w":22,"h":28,"txtscale":100,"bOffBottom":0}
,
"text1579":{"x":66,"y":231,"w":22,"h":28,"txtscale":100,"bOffBottom":0}
,
"text1580":{"x":306,"y":231,"w":21,"h":28,"txtscale":100,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}

Init_qu1572(false, true);
}
,
"RCDResultResize":function(){}
,"preload":[]
}}
