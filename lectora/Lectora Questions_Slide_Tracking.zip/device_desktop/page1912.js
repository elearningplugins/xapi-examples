DesktopResponsive={"1009":{
"pageLayer":{"w":1009,"h":662,"bgColor":"#ffffff"}
,
"text2639":{"x":900,"y":0,"w":109,"h":19,"txtscale":100,"bOffBottom":0}
,
"button2174":{"B64":{"disabledState":"","downState":"","normalState":"","overState":""},"bOffBottom":0,"h":42,"i":"images/button2174.png","idis":"images/button2174_disabled.png","ion":"images/button2174_down.png","irol":"images/button2174_over.png","p":"M 11.000000 1.000000 L 111.000000 1.000000 L 113.000000 1.187500 L 114.937500 1.812500 L 118.062500 3.937500 L 120.250000 7.125000 L 120.812500 9.000000 L 121.000000 11.000000 L 121.000000 31.000000 L 120.812500 33.000000 L 120.250000 34.937500 L 118.062500 38.062500 L 114.937500 40.250000 L 113.000000 40.812500 L 111.000000 41.000000 L 11.000000 41.000000 L 7.187500 40.250000 L 3.937500 38.125000 L 1.750000 34.875000 L 1.187500 33.000000 L 1.000000 31.000000 L 1.000000 11.000000 L 1.187500 9.000000 L 1.812500 7.125000 L 3.937500 3.937500 L 7.125000 1.812500 L 9.000000 1.187500 L 11.000000 1.000000 z","stylemods":[{"decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:120.000000px; height:40.000000px;}","sel":"div.button2174Text"},{"decl":" { width:112.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button2174Text"},{"decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:120.000000px; height:40.000000px;}","sel":"div.button2174overStateText"},{"decl":" { width:112.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button2174overStateText"},{"decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:120.000000px; height:40.000000px;}","sel":"div.button2174downStateText"},{"decl":" { width:112.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button2174downStateText"},{"decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:120.000000px; height:40.000000px;}","sel":"div.button2174disabledStateText"},{"decl":" { width:112.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button2174disabledStateText"}],"w":122,"x":140,"y":357}
,
"shape6097":{"x":-1,"y":47,"w":1011.000000,"h":90.000000,"stylemods":[{"sel":"div.shape6097Text","decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:1009.000000px; height:88.000000px;}"},{"sel":"span.shape6097Text","decl":" { width:1005.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAA/MAAABaCAYAAAD0BwYYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAF3SURBVHhe7cExAQAAAMKg9U/tZwogAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOBqjl0AAUMqMU8AAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 1.000000 1.000000 L 1010.000000 1.000000 L 1010.000000 89.000000 L 1.000000 89.000000 L 1.000000 1.000000 z" ,"i":"images/shape6097.png"}
,
"text1918":{"x":20,"y":72,"w":968,"h":41,"txtscale":100,"bOffBottom":0}
,
"image1916":{"x":602,"y":185,"w":308,"h":308,"bOffBottom":0,"i":"images/trivsampledropimage.png"}
,
"text1919":{"x":140,"y":185,"w":150,"h":35,"txtscale":100,"bOffBottom":0}
,
"text1920":{"x":138,"y":243,"w":135,"h":30,"txtscale":100,"bOffBottom":0}
,
"text1921":{"x":139,"y":299,"w":168,"h":31,"txtscale":100,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
dragMgr.addDrop( 656, 205, 220, 70, 'A',1, Update_qu1913 );
dragMgr.addDrop( 656, 302, 220, 70, 'B',1, Update_qu1913 );
dragMgr.addDrop( 656, 397, 220, 70, 'C',1, Update_qu1913 );

Init_qu1913(false, true);
}
,
"RCDResultResize":function(){}
,"preload":['images/trivsampledropimage.png','images/button2174.png','images/button2174_over.png','images/button2174_down.png','images/button2174_disabled.png','images/shape6097.png']
}}
