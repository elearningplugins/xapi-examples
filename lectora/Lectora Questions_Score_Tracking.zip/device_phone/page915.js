PhoneResponsive={"785":{
"pageLayer":{"w":785,"h":450,"bgColor":"#ffffff"}
,
"text2639":{"x":700,"y":0,"w":85,"h":18,"txtscale":100,"bOffBottom":0}
,
"button976":{"B64":{"disabledState":"","downState":"","normalState":"","overState":""},"bOffBottom":0,"h":33,"p":"M 8.000000 1.000000 L 87.000000 1.000000 L 89.750000 1.562500 L 91.937500 3.062500 L 93.437500 5.312500 L 94.000000 8.000000 L 94.000000 25.000000 L 93.437500 27.750000 L 91.937500 29.937500 L 89.750000 31.437500 L 87.000000 32.000000 L 8.000000 32.000000 L 5.375000 31.500000 L 3.062500 30.000000 L 1.562500 27.687500 L 1.000000 25.000000 L 1.000000 8.000000 L 1.562500 5.312500 L 3.062500 3.062500 L 5.312500 1.562500 L 8.000000 1.000000 z","stylemods":[{"decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:93.000000px; height:31.000000px;}","sel":"div.button976Text"},{"decl":" { width:87.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button976Text"},{"decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:93.000000px; height:31.000000px;}","sel":"div.button976overStateText"},{"decl":" { width:87.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button976overStateText"},{"decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:93.000000px; height:31.000000px;}","sel":"div.button976downStateText"},{"decl":" { width:87.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button976downStateText"},{"decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:93.000000px; height:31.000000px;}","sel":"div.button976disabledStateText"},{"decl":" { width:87.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button976disabledStateText"}],"w":95,"x":109,"y":207}
,
"shape5969":{"x":-1,"y":36,"w":787.000000,"h":70.000000,"stylemods":[{"sel":"div.shape5969Text","decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:785.000000px; height:68.000000px;}"},{"sel":"span.shape5969Text","decl":" { width:781.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAxMAAABGCAYAAAC38cmJAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADtSURBVHhe7cExAQAAAMKg9U9tCj8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOKsBXTsAAancZPgAAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 1.000000 1.000000 L 786.000000 1.000000 L 786.000000 69.000000 L 1.000000 69.000000 L 1.000000 1.000000 z"}
,
"text918":{"x":109,"y":58,"w":567,"h":56,"txtscale":100,"bOffBottom":0}
,
"entry919":{"x":109,"y":156,"w":160,"h":25,"fsize":16,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":[]
},
"480":{
"pageLayer":{"w":480,"h":763,"bgColor":"#ffffff"}
,
"text2639":{"x":428,"y":0,"w":52,"h":18,"txtscale":100,"bOffBottom":0}
,
"button976":{"B64":{"disabledState":"","downState":"","normalState":"","overState":""},"bOffBottom":0,"h":21,"p":"M 5.000000 1.000000 L 54.000000 1.000000 L 55.562500 1.312500 L 56.875000 2.187500 L 57.687500 3.437500 L 58.000000 5.000000 L 58.000000 16.000000 L 57.687500 17.562500 L 56.875000 18.875000 L 55.562500 19.687500 L 54.000000 20.000000 L 5.000000 20.000000 L 3.500000 19.750000 L 2.187500 18.875000 L 1.312500 17.562500 L 1.000000 16.000000 L 1.000000 5.000000 L 1.312500 3.437500 L 2.187500 2.187500 L 3.437500 1.312500 L 5.000000 1.000000 z","stylemods":[{"decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:57.000000px; height:19.000000px;}","sel":"div.button976Text"},{"decl":" { width:51.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button976Text"},{"decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:57.000000px; height:19.000000px;}","sel":"div.button976overStateText"},{"decl":" { width:51.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button976overStateText"},{"decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:57.000000px; height:19.000000px;}","sel":"div.button976downStateText"},{"decl":" { width:51.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button976downStateText"},{"decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:57.000000px; height:19.000000px;}","sel":"div.button976disabledStateText"},{"decl":" { width:51.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button976disabledStateText"}],"w":59,"x":67,"y":266}
,
"shape5969":{"x":-1,"y":47,"w":482.000000,"h":44.000000,"stylemods":[{"sel":"div.shape5969Text","decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:480.000000px; height:42.000000px;}"},{"sel":"span.shape5969Text","decl":" { width:476.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAeIAAAAsCAYAAAC5fLvTAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABoSURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAt2pLmwAB3OvSpQAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 1.000000 1.000000 L 481.000000 1.000000 L 481.000000 43.000000 L 1.000000 43.000000 L 1.000000 1.000000 z"}
,
"text918":{"x":66,"y":95,"w":347,"h":74,"txtscale":100,"bOffBottom":0}
,
"entry919":{"x":66,"y":183,"w":160,"h":25,"fsize":16,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":[]
}}
