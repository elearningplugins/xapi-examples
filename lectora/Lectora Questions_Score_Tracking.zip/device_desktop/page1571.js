DesktopResponsive={"1009":{
"pageLayer":{"w":1009,"h":662,"bgColor":"#ffffff"}
,
"text2639":{"x":900,"y":0,"w":109,"h":19,"txtscale":100,"bOffBottom":0}
,
"button1684":{"B64":{"disabledState":"","downState":"","normalState":"","overState":""},"bOffBottom":0,"h":42,"i":"images/button1684.png","idis":"images/button1684_disabled.png","ion":"images/button1684_down.png","irol":"images/button1684_over.png","p":"M 11.000000 1.000000 L 111.000000 1.000000 L 113.000000 1.187500 L 114.937500 1.812500 L 118.062500 3.937500 L 120.250000 7.125000 L 120.812500 9.000000 L 121.000000 11.000000 L 121.000000 31.000000 L 120.812500 33.000000 L 120.250000 34.937500 L 118.062500 38.062500 L 114.937500 40.250000 L 113.000000 40.812500 L 111.000000 41.000000 L 11.000000 41.000000 L 7.187500 40.250000 L 3.937500 38.125000 L 1.750000 34.875000 L 1.187500 33.000000 L 1.000000 31.000000 L 1.000000 11.000000 L 1.187500 9.000000 L 1.812500 7.125000 L 3.937500 3.937500 L 7.125000 1.812500 L 9.000000 1.187500 L 11.000000 1.000000 z","stylemods":[{"decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:120.000000px; height:40.000000px;}","sel":"div.button1684Text"},{"decl":" { width:112.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button1684Text"},{"decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:120.000000px; height:40.000000px;}","sel":"div.button1684overStateText"},{"decl":" { width:112.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button1684overStateText"},{"decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:120.000000px; height:40.000000px;}","sel":"div.button1684downStateText"},{"decl":" { width:112.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button1684downStateText"},{"decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:120.000000px; height:40.000000px;}","sel":"div.button1684disabledStateText"},{"decl":" { width:112.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button1684disabledStateText"}],"w":122,"x":140,"y":312}
,
"shape6027":{"x":-1,"y":47,"w":1011.000000,"h":90.000000,"stylemods":[{"sel":"div.shape6027Text","decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:1009.000000px; height:88.000000px;}"},{"sel":"span.shape6027Text","decl":" { width:1005.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAA/MAAABaCAYAAAD0BwYYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAF3SURBVHhe7cExAQAAAMKg9U/tZwogAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOBqjl0AAUMqMU8AAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 1.000000 1.000000 L 1010.000000 1.000000 L 1010.000000 89.000000 L 1.000000 89.000000 L 1.000000 1.000000 z" ,"i":"images/shape6027.png"}
,
"text1574":{"x":140,"y":74,"w":729,"h":37,"txtscale":100,"bOffBottom":0}
,
"text1575":{"x":140,"y":175,"w":20,"h":28,"txtscale":100,"bOffBottom":0}
,
"text1576":{"x":644,"y":175,"w":20,"h":28,"txtscale":100,"bOffBottom":0}
,
"text1577":{"x":140,"y":222,"w":20,"h":28,"txtscale":100,"bOffBottom":0}
,
"text1578":{"x":644,"y":222,"w":21,"h":28,"txtscale":100,"bOffBottom":0}
,
"text1579":{"x":140,"y":269,"w":21,"h":28,"txtscale":100,"bOffBottom":0}
,
"text1580":{"x":644,"y":269,"w":20,"h":28,"txtscale":100,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}

Init_qu1572(false, true);
}
,
"RCDResultResize":function(){}
,"preload":['images/button1684.png','images/button1684_over.png','images/button1684_down.png','images/button1684_disabled.png','images/shape6027.png']
}}
