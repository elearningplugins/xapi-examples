DesktopResponsive={"1009":{
"pageLayer":{"w":1009,"h":662,"bgColor":"#ffffff"}
,
"text2639":{"x":900,"y":0,"w":109,"h":19,"txtscale":100,"bOffBottom":0}
,
"button123":{"B64":{"disabledState":"","downState":"","normalState":"","overState":""},"bOffBottom":0,"h":42,"i":"images/button123.png","idis":"images/button123_disabled.png","ion":"images/button123_down.png","irol":"images/button123_over.png","p":"M 11.000000 1.000000 L 111.000000 1.000000 L 113.000000 1.187500 L 114.937500 1.812500 L 118.062500 3.937500 L 120.250000 7.125000 L 120.812500 9.000000 L 121.000000 11.000000 L 121.000000 31.000000 L 120.812500 33.000000 L 120.250000 34.937500 L 118.062500 38.062500 L 114.937500 40.250000 L 113.000000 40.812500 L 111.000000 41.000000 L 11.000000 41.000000 L 7.187500 40.250000 L 3.937500 38.125000 L 1.750000 34.875000 L 1.187500 33.000000 L 1.000000 31.000000 L 1.000000 11.000000 L 1.187500 9.000000 L 1.812500 7.125000 L 3.937500 3.937500 L 7.125000 1.812500 L 9.000000 1.187500 L 11.000000 1.000000 z","stylemods":[{"decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:120.000000px; height:40.000000px;}","sel":"div.button123Text"},{"decl":" { width:112.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button123Text"},{"decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:120.000000px; height:40.000000px;}","sel":"div.button123overStateText"},{"decl":" { width:112.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button123overStateText"},{"decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:120.000000px; height:40.000000px;}","sel":"div.button123downStateText"},{"decl":" { width:112.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button123downStateText"},{"decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:120.000000px; height:40.000000px;}","sel":"div.button123disabledStateText"},{"decl":" { width:112.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}","sel":"span.button123disabledStateText"}],"w":122,"x":132,"y":295}
,
"shape5651":{"x":-1,"y":47,"w":1011.000000,"h":90.000000,"stylemods":[{"sel":"div.shape5651Text","decl":" { position:absolute; top:1.000000px; left:1.000000px; display:flex; justify-content:center; align-items:center; width:1009.000000px; height:88.000000px;}"},{"sel":"span.shape5651Text","decl":" { width:1005.000000px; margin-right:5px; margin-left:5px; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAA/MAAABaCAYAAAD0BwYYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAF3SURBVHhe7cExAQAAAMKg9U/tZwogAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOBqjl0AAUMqMU8AAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 1.000000 1.000000 L 1010.000000 1.000000 L 1010.000000 89.000000 L 1.000000 89.000000 L 1.000000 1.000000 z" ,"i":"images/shape5651.png"}
,
"text87":{"x":0,"y":73,"w":1009,"h":39,"txtscale":100,"bOffBottom":0}
,
"text88":{"x":163,"y":183,"w":702,"h":37,"txtscale":100,"bOffBottom":0}
,
"radio89":{"x":133,"y":182,"fsize":16,"bOffBottom":0}
,
"text90":{"x":163,"y":228,"w":702,"h":37,"txtscale":100,"bOffBottom":0}
,
"radio91":{"x":133,"y":227,"fsize":16,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":['images/button123.png','images/button123_over.png','images/button123_down.png','images/button123_disabled.png','images/shape5651.png']
}}
