//Change the reseller name within double quotes
var bridgeURL = "http://tripletech.biz/bridge.php";

var resellerName = "";
var downloadURL = "http://tripletech.biz/new_interface/handbooks/Awkward_at_the_Office.zip"